# Cave Homes Spain — Version 5

This is the next step from V4: a polished marketplace frontend plus a real Supabase database schema and a deployment-ready structure.

## What is included

- Responsive marketplace homepage
- Search by location/keyword, property type and maximum price
- Featured listings
- Favorites
- Property detail modal
- Buyer enquiry flow
- Seller submission form
- Owner dashboard counters
- Demo-data export
- Supabase-ready schema for:
  - users/profiles
  - properties
  - property photos
  - favorites
  - enquiries
  - seller submissions
- Clear separation between demo/local behavior and live backend integration

## Important

The website is **not connected to your accounts yet**. The HTML currently runs with demo data so you can preview it immediately.

To make it a real marketplace, connect:
1. Vercel (hosting)
2. Supabase (database, authentication and photo storage)
3. Your domain
4. Stripe later for paid Featured/Premium listings
5. Email/WhatsApp later for enquiry notifications

Supabase's official JavaScript client can be loaded through a CDN, which is what this simple V5 frontend is prepared for.

## 1. Put the site online quickly

### Easiest route: Vercel

Create a free Vercel account, then import this folder/repository.

Or install the Vercel CLI and run from this folder:

    npm i -g vercel
    vercel

For the production deployment:

    vercel --prod

Vercel creates a live deployment URL. You can later connect a custom domain in the Vercel dashboard.

## 2. Create your Supabase project

Create a Supabase project.

Open the SQL Editor and run:

    supabase/schema.sql

Then copy your project's URL and publishable/anon key.

In `index.html`, change:

    const CONFIG={SUPABASE_URL:"",SUPABASE_PUBLISHABLE_KEY:""};

to your values.

Do NOT put a service-role key in this browser application.

## 3. Make the database live

The next development pass should replace the demo `listings` array with Supabase queries such as:

    supabase.from('properties').select('*').eq('status','published')

and replace localStorage favorites/enquiries with the Supabase tables.

## 4. Photo storage

Create a Supabase Storage bucket such as:

    property-images

Then add storage policies allowing authenticated sellers to upload only to their own property folders, and public buyers to read published images.

## 5. Accounts

Enable email/password authentication in Supabase.

Recommended roles:

- buyer
- seller
- admin

For production, role changes should be controlled server-side/admin-only.

## 6. Paid listings

Keep the marketplace free at launch.

Suggested initial products:
- Free — 1 listing
- Featured — €29/month
- Premium — €59/month

Use Stripe Checkout + a server-side webhook/edge function to update the property's featured/subscription status.

## 7. Before public launch

Do these before accepting real customer data or payments:

- Add your legal company/business details
- Privacy policy
- Cookie/analytics notice where applicable
- Terms of use
- Seller/property verification process
- Clear property status (available, reserved, sold)
- Admin authentication
- Rate limiting / spam protection
- Email notification service
- Image moderation/size limits
- Backups
- Error monitoring
- Real domain and branded email

## 8. Recommended launch order

Phase 1:
- Put V5 on Vercel
- Buy/connect domain
- Create Supabase project
- Run schema
- Connect live property listings
- Enable seller/buyer accounts

Phase 2:
- Photo uploads
- Admin approval
- Email/WhatsApp enquiry notifications
- SEO pages for towns such as Galera, Benamaurel, Castilléjar, Guadix

Phase 3:
- Stripe Featured/Premium listings
- Analytics
- Reviews/testimonials
- Interactive map
- Spanish/English/other languages

## Files

- `index.html` — V5 frontend
- `supabase/schema.sql` — database schema + starter RLS policies
- `README.md` — this guide
