-- Cave Homes Spain — Supabase schema
-- Run this in Supabase SQL Editor after creating your project.
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'buyer' check (role in ('buyer','seller','admin')),
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references public.profiles(id) on delete set null,
  title text not null,
  slug text unique,
  town text not null,
  province text not null default 'Granada',
  price numeric(12,2) not null check (price >= 0),
  bedrooms integer default 0,
  bathrooms integer default 0,
  area_m2 numeric(10,2),
  property_type text not null default 'Ready to move in',
  description text,
  status text not null default 'pending' check (status in ('draft','pending','published','rejected','sold')),
  featured boolean not null default false,
  latitude double precision,
  longitude double precision,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.property_images (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  storage_path text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, property_id)
);

create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  property_id uuid references public.properties(id) on delete set null,
  buyer_id uuid references public.profiles(id) on delete set null,
  buyer_name text not null,
  buyer_email text not null,
  buyer_phone text,
  message text,
  status text not null default 'new' check (status in ('new','read','replied','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.listing_submissions (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid references public.profiles(id) on delete set null,
  name text not null,
  email text not null,
  town text not null,
  asking_price numeric(12,2),
  property_type text,
  description text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.property_images enable row level security;
alter table public.favorites enable row level security;
alter table public.enquiries enable row level security;
alter table public.listing_submissions enable row level security;

-- Public buyers can see published properties and their images.
create policy "published properties are public" on public.properties
for select using (status = 'published');

create policy "published images are public" on public.property_images
for select using (exists (
  select 1 from public.properties p
  where p.id = property_images.property_id and p.status = 'published'
));

-- Authenticated users manage their own favorites.
create policy "users read own favorites" on public.favorites
for select using (auth.uid() = user_id);
create policy "users insert own favorites" on public.favorites
for insert with check (auth.uid() = user_id);
create policy "users delete own favorites" on public.favorites
for delete using (auth.uid() = user_id);

-- Buyers can submit enquiries. Owners/admins should be handled with
-- additional policies or a server-side function once roles are wired.
create policy "buyers submit enquiries" on public.enquiries
for insert with check (auth.uid() = buyer_id or buyer_id is null);

create policy "sellers submit listings" on public.listing_submissions
for insert with check (auth.uid() = seller_id or seller_id is null);

-- Profile creation/read policy.
create policy "users read own profile" on public.profiles
for select using (auth.uid() = id);
create policy "users create own profile" on public.profiles
for insert with check (auth.uid() = id);

-- IMPORTANT:
-- Add admin-only policies before using the admin dashboard in production.
-- Never put a Supabase service-role key in browser code.
